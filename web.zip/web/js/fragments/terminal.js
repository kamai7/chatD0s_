class Terminal extends Fragment {
    constructor(terminal_prompts) {
        super("terminal", terminal_prompts);
    }
}